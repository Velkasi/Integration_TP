import pandas as pd
import pymysql

DB_HOST = 'localhost'
DB_PORT = 3306
DB_NAME = 'university'
DB_USER = ''
DB_PASS = ''

df_students = pd.read_csv('students_clean.csv')
df_enrollments = pd.read_csv('enrollments_clean.csv')
df_majors = pd.read_csv('majors.csv')

conn = pymysql.connect(
    host=DB_HOST,
    port=DB_PORT,
    user=DB_USER,
    password=DB_PASS,
    database=DB_NAME,
    autocommit=False,
    charset='utf8mb4'
)

try:
    with conn.cursor() as cursor:
        # Insertion Majors, students et enrollments
        majors_insert = """
            INSERT IGNORE INTO majors (major_code, major_name)
            VALUES (%s, %s)
        """
        cursor.executemany(majors_insert, df_majors.values.tolist())

        student_insert = """
            INSERT INTO students (student_id, full_name, birth_date, email, nationality)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.executemany(student_insert, df_students.values.tolist())

        enrollment_insert = """
            INSERT INTO enrollments (student_id, major_code, registration_date, status)
            VALUES (%s, %s, %s, %s)
        """
        cursor.executemany(enrollment_insert, df_enrollments.values.tolist())

    conn.commit()
    print("Data loaded successfully into the database.")

except Exception as e:
    conn.rollback()
    print("Error loading data:", e)

finally:
    conn.close()
